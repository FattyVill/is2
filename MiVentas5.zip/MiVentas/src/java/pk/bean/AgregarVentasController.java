/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import pk.entities.Clientes;
import pk.entities.Productos;
import pk.entities.Vendedores;
import pk.entities.VentasDet;
import pk.session.ClientesFacade;
import pk.session.ProductosFacade;
import pk.session.VendedoresFacade;

@Named("agregarVentasController")
@SessionScoped
public class AgregarVentasController implements Serializable {

    @EJB
    private final ClientesFacade clientesFacade;
    @EJB
    private final VendedoresFacade vendedoresFacade;
    @EJB
    private ProductosFacade productosFacade = new ProductosFacade();
    
    
    private String idVenta;
    private String fechaVenta;
    private Integer idCliente;
    private Integer idVendedor;
    private  List<Clientes> clientesList;
    private  List<Vendedores> vendedoresList;
    private  List<Productos> productosList = new ArrayList<>(); //comboProductos
    private Productos producto;
    private int cantidad;
    private ArrayList<VentasDet> listaDetalle = new ArrayList<VentasDet>();
    
    public AgregarVentasController() {
        this.productosFacade = new ProductosFacade();
        this.clientesFacade = new ClientesFacade();
        this.vendedoresFacade = new VendedoresFacade();

    }

    /**
     *
     * @param idCliente
     */
    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;

    }

    public Integer getidCliente() {
        return getIdCliente();
    }

    public void setIdVendedor(Integer idVendedor) {
        this.idVendedor = idVendedor;

    }

    public Integer getidVendedor() {
        return idVendedor;
    }

    public String getNroVenta() {
        return idVenta;
    }

    public void setNroVenta(String idVenta) {
        this.idVenta = idVenta;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fecha) {
        this.fechaVenta = fecha;
    }
    private Connection con = null;

    @PostConstruct
    void initialiseSession() {
        con = DataConnect.getConnection();
        this.cargarVista();
    }

    public void cargarVista() {

        int nuevaSeq = obtenerNroVenta();
        if (nuevaSeq < 10) {
            this.idVenta = "000" + String.valueOf(nuevaSeq);
        } else if (nuevaSeq < 100) {
            this.idVenta = "0" + String.valueOf(nuevaSeq);
        } else {
            this.idVenta = String.valueOf(nuevaSeq);
        }

        Date date = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String today = formatter.format(date);
        this.fechaVenta = today;

        this.setClientesList(clientesFacade.findAll());
        this.setVendedoresList(vendedoresFacade.findAll());
        this.setProductosList(productosFacade.findAll());
    }

    public int obtenerNroVenta() {
        int ultimoValor = 0;
        try {
            PreparedStatement ps = con.prepareStatement("SELECT last_value FROM id_venta_sequence");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BigDecimal uv = rs.getBigDecimal("last_value");
                ultimoValor = uv.toBigInteger().intValue();
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener secuencia >"
                    + ex.getMessage());
        }
        return ultimoValor;
    }
    public void agregarProducto() {
    
    }
    
    public void setCantidad (Integer cantidad) {
        this.cantidad = cantidad;

    }

    public Integer getCantidad() {
        return cantidad;
    }
    
    public void SetProductos (Productos productos){
    this.producto=productos;
    }
    public Productos GetProductos (){
    return producto;
    }

    /**
     * @return the idCliente
     */
    public Integer getIdCliente() {
        return idCliente;
    }

    /**
     * @return the clientesList
     */
    public List<Clientes> getClientesList() {
        return clientesList;
    }

    /**
     * @param clientesList the clientesList to set
     */
    public void setClientesList(List<Clientes> clientesList) {
        this.clientesList = clientesList;
    }

    /**
     * @return the vendedoresList
     */
    public List<Vendedores> getVendedoresList() {
        return vendedoresList;
    }

    /**
     * @param vendedoresList the vendedoresList to set
     */
    public void setVendedoresList(List<Vendedores> vendedoresList) {
        this.vendedoresList = vendedoresList;
    }

    /**
     * @return the productosList
     */
    public List<Productos> getProductosList() {
        return productosList;
    }

    /**
     * @param productosList the productosList to set
     */
    public void setProductosList(List<Productos> productosList) {
        this.productosList = productosList;
    }
    
    
}
