/*
 * 
 */
package pk.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import pk.entities.Clientes;
import pk.entities.Productos;
import pk.entities.Vendedores;
import pk.entities.VentasDet;
import pk.session.ClientesFacade;
import pk.session.ProductosFacade;
import pk.session.VendedoresFacade;

@Named("agregarVentasController")
@SessionScoped
public class agregarVentasController implements Serializable {

    @EJB
    private ClientesFacade clientesFacade;
    @EJB
    private VendedoresFacade vendedoresFacade;
    @EJB
    private ProductosFacade productosFacade = new ProductosFacade();
    private String idVenta;    private String fecha;

    private Integer idCliente;
    private Integer idVendedor;
    private String cliente;
    private Vendedores vendedor;
    private Productos producto;
    private int cantidad;
    private List<Vendedores> vendedoresList = new ArrayList<Vendedores>();
    private List<Clientes> clientesList = new ArrayList<Clientes>();
    private List<Productos> productosList = new ArrayList<Productos>();
    private ArrayList<VentasDet> listaDetalle = new ArrayList<VentasDet>();

    public ClientesFacade getClientesFacade() {
        return clientesFacade;
    }

    public void setClientesFacade(ClientesFacade clientesFacade) {
        this.clientesFacade = clientesFacade;
    }

    public VendedoresFacade getVendedoresFacade() {
        return vendedoresFacade;
    }

    public void setVendedoresFacade(VendedoresFacade vendedoresFacade) {
        this.vendedoresFacade = vendedoresFacade;
    }

    public Connection getCon() {
        return con;
    }

    public void setCon(Connection con) {
        this.con = con;
    }

    public String getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(String idVenta) {
        this.idVenta = idVenta;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public Integer getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(Integer idVendedor) {
        this.idVendedor = idVendedor;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public Vendedores getVendedor() {
        return vendedor;
    }

    public void setVendedor(Vendedores vendedor) {
        this.vendedor = vendedor;
    }
    private Connection con = null;

    @PostConstruct
    void initialiseSession() {
        con = DataConnect.getConnection();
        this.cargarVista();
    }

    public void cargarVista() {
        int nuevaSeq = obtenerNroVenta();
        if (nuevaSeq < 10) {
            this.idVenta = "000" + String.valueOf(nuevaSeq);
        } else if (nuevaSeq < 100) {
            this.idVenta = "0" + String.valueOf(nuevaSeq);
        } else {
            this.idVenta = String.valueOf(nuevaSeq);
        }
        Date date = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String today = formatter.format(date);
        this.fecha = today;
        this.clientesList = clientesFacade.findAll();
        this.vendedoresList = vendedoresFacade.findAll();
        this.productosList = productosFacade.findAll();
    }

    public int obtenerNroVenta() {
        int ultimoValor = 0;
        try {
            PreparedStatement ps = con.prepareStatement("SELECT last_value FROM id_venta_sequence");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BigDecimal uv = rs.getBigDecimal("last_value");
                ultimoValor = uv.toBigInteger().intValue();
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener secuencia "
                    + ex.getMessage());
        }
        return ultimoValor;
    }

    public List<Vendedores> getVendedoresList() {
        return vendedoresList;
    }

    public void setVendedoresList(List<Vendedores> vendedoresList) {
        this.vendedoresList = vendedoresList;
    }

    public List<Clientes> getClientesList() {
        return clientesList;
    }

    public void setClientesList(List<Clientes> clientesList) {
        this.clientesList = clientesList;
    }

    public ProductosFacade getProductosFacade() {
        return productosFacade;
    }

    public void setProductosFacade(ProductosFacade productosFacade) {
        this.productosFacade = productosFacade;
    }

    public Productos getProducto() {
        return producto;
    }

    public void setProducto(Productos producto) {
        this.producto = producto;
    }

    public List<Productos> getProductosList() {
        return productosList;
    }

    public void setProductosList(List<Productos> productosList) {
        this.productosList = productosList;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public ArrayList<VentasDet> getListaDetalle() {
        return listaDetalle;
    }

    public void setListaDetalle(ArrayList<VentasDet> listaDetalle) {
        this.listaDetalle = listaDetalle;
    }
    
    public void agregarProducto() {
    
    }
    
}
