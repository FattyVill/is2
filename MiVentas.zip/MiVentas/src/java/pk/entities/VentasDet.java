/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author admin_2
 */
@Entity
@Table(name = "ventas_det")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "VentasDet.findAll", query = "SELECT v FROM VentasDet v"),
    @NamedQuery(name = "VentasDet.findByIdVentaDet", query = "SELECT v FROM VentasDet v WHERE v.idVentaDet = :idVentaDet"),
    @NamedQuery(name = "VentasDet.findByCantidad", query = "SELECT v FROM VentasDet v WHERE v.cantidad = :cantidad"),
    @NamedQuery(name = "VentasDet.findByTotalProducto", query = "SELECT v FROM VentasDet v WHERE v.totalProducto = :totalProducto"),
    @NamedQuery(name = "VentasDet.findByIdVenta", query = "SELECT v FROM VentasDet v WHERE v.idVenta = :idVenta")})
public class VentasDet implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_venta_det")
    private Integer idVentaDet;
    @Column(name = "cantidad")
    private Integer cantidad;
    @Column(name = "total_producto")
    private Integer totalProducto;
    @Column(name = "id_venta")
    private Integer idVenta;
    @JoinColumn(name = "id_producto", referencedColumnName = "id_producto")
    @ManyToOne
    private Productos idProducto;

    public VentasDet() {
    }

    public VentasDet(Integer idVentaDet) {
        this.idVentaDet = idVentaDet;
    }

    public Integer getIdVentaDet() {
        return idVentaDet;
    }

    public void setIdVentaDet(Integer idVentaDet) {
        this.idVentaDet = idVentaDet;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getTotalProducto() {
        return totalProducto;
    }

    public void setTotalProducto(Integer totalProducto) {
        this.totalProducto = totalProducto;
    }

    public Integer getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(Integer idVenta) {
        this.idVenta = idVenta;
    }

    public Productos getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Productos idProducto) {
        this.idProducto = idProducto;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idVentaDet != null ? idVentaDet.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof VentasDet)) {
            return false;
        }
        VentasDet other = (VentasDet) object;
        if ((this.idVentaDet == null && other.idVentaDet != null) || (this.idVentaDet != null && !this.idVentaDet.equals(other.idVentaDet))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pk.VentasDet[ idVentaDet=" + idVentaDet + " ]";
    }
    
}
